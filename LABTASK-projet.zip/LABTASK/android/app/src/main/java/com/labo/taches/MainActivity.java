package com.labo.taches;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}

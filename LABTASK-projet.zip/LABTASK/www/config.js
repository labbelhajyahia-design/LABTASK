/* Réglages de l'appli Tâches Labo */
window.LABO_CONFIG = {
  /* Identifiant du laboratoire dans la base en ligne (ne pas changer après la mise en service) */
  labId: 'miFarsdkkyv6LQehH10l',

  /* Empreinte du code spécial qui débloque le mode Biologiste (le code lui-même n'est pas stocké) */
  bioCodeHash: '17982d595b7ff9747dfb596b56e6c3e7b30d94945a5367d4145634adda018493',

  /* Base en ligne Firebase (projet labtask-16cf8) : partage des tâches entre les téléphones */
  firebase: {
    apiKey: 'AIzaSyCykFNfK2PjZJSJNdTl6b4cs0Ej7x4fpFY',
    authDomain: 'labtask-16cf8.firebaseapp.com',
    projectId: 'labtask-16cf8',
    storageBucket: 'labtask-16cf8.firebasestorage.app',
    messagingSenderId: '511897957948',
    appId: '1:511897957948:web:711e43718213b26d387539'
  }
};
